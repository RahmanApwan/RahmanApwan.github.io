<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}
                                                                                   
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db_transaksi";

$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

$no_transaksi = $_POST['no_transaksi'];
$tanggal = $_POST['Tanggal'];
$nama_cus = $_POST['nama_cus'];
$id_paket = $_POST['id_paket'];
$total = $_POST['total'];
$pembayaran = $_POST['pembayaran'];
$kembalian = $_POST['kembalian'];

$sql = "INSERT INTO transaksi (no_transaksi, tanggal, nama_customer, id_paket, total, pembayaran, kembalian)
        VALUES ('$no_transaksi', '$tanggal', '$nama_cus', '$id_paket', '$total', '$pembayaran', '$kembalian')";

if ($conn->query($sql) === TRUE) {
    echo "Transaksi berhasil disimpan.";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
