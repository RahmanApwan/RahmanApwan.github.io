<?php
session_start();

// Hapus semua variabel sesi
session_unset();

session_destroy();

header("Location: login.php");
exit();
?>
