<?php
$host = 'localhost';
$user = 'root';
$pass = '';
$db = 'db_login';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

$username = $_POST['username'];
$password = $_POST['password'];

$username = mysqli_real_escape_string($conn, $username);

$hashed_password = password_hash($password, PASSWORD_DEFAULT);

$query = "INSERT INTO users (username, password) VALUES ('$username', '$hashed_password')";

if ($conn->query($query) === TRUE) {
    echo "Registrasi berhasil!";
} else {
    echo "Error: " . $query . "<br>" . $conn->error;
}

$conn->close();
?>
