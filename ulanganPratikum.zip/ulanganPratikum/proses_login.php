<?php
$host = 'localhost';
$user = 'root';
$pass = '';
$db = 'db_login';

$conn = new mysqli($host, $user, $pass, $db);


if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

$username = $_POST['username'];
$password = $_POST['password'];


$username = mysqli_real_escape_string($conn, $username);

$query = "SELECT * FROM users WHERE username='$username'";
$result = $conn->query($query);


if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $hashed_password_from_db = $row['password'];

    if (password_verify($password, $hashed_password_from_db)) {

        session_start();
        $_SESSION['username'] = $username;
        header("Location: index.php");
        exit();
    } else {
        header("Location: login.php?error=invalid");
        exit();
    }
} else {
    header("Location: login.php?error=invalid");
    exit();
}

$conn->close();
?>
