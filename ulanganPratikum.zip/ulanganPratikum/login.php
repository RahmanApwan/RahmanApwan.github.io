<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>
<div class="container">
    <div class="logo">
       
        <div class="gambar-container">
        <img src="ytta.jpg" width="300" height="1000"><br>
    </div><br><br>
<script src="https://cdn.tailwindcss.com"></script>
<body class="flex items-center justify-center h-screen bg-gray-100">
    <form action="proses_login.php" method="post" class="bg-white p-8 rounded shadow-md w-96">
        <h2 class="text-2xl font-semibold mb-6">CarWash SMkN 2 BANJARMASIN</h2>
        <h3 class="text-2xl font-semibold mb-4">Silahkan login terlebih </h3>

        <div class="mb-4">
            <label for="username" class="block text-sm font-medium text-gray-600">Username</label>
            <input type="text" id="username" name="username" placeholder="Enter your username" required
                class="w-full border rounded px-3 py-2 mt-1">
        </div>

        <div class="mb-4">
            <label for="password" class="block text-sm font-medium text-gray-600">Password</label>
            <input type="password" id="password" name="password" required placeholder="Enter your password"
                class="w-full border rounded px-3 py-2 mt-1">
        </div>

        <?php if (isset($_GET['error']) && $_GET['error'] == 'invalid') : ?>
            <p class="text-red-500 mb-4">Login failed. Check your username and password.</p>
        <?php endif; ?>

        <button type="submit" class="bg-blue-900 text-white px-4 py-2 rounded hover:bg-red-950">Login</button>

        <p class="mt-4 text-sm">
            Don't have an account?
            <a href="register.php" class="text-red-500">Register</a>
        </p>
    </form>
</body>
</html>
