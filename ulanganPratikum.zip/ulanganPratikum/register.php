<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="flex items-center justify-center h-screen bg-gray-100">
    <div class="bg-white p-8 rounded shadow-md w-96">
        <form action="proses_register.php" method="post">
            <div class="mb-4">
                <label for="username" class="block text-sm font-medium text-gray-600">Username:</label>
                <input type="text" id="username" name="username" required
                    class="w-full border rounded px-3 py-2 mt-1">
            </div>

            <div class="mb-4">
                <label for="password" class="block text-sm font-medium text-gray-600">Password:</label>
                <input type="password" id="password" name="password" required
                    class="w-full border rounded px-3 py-2 mt-1">
            </div>

            <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">Register</button>

            <p class="mt-4 text-sm">
            Already have an account?
            <a href="login.php" class="text-blue-500">Login</a>
        </p>
        </form>
    </div>
</body>
</html>
