const http = require('http')
const fs = require('fs')
const querystring = require('querystring')
const url = require('url')
const users = require('./user')

const hostname = "127.0.0.1"
const port = 3000

http.createServer(async (req,res) =>{
   const reqUrl = req.url
   const method = req.method

    if(reqUrl == "/"){
        if(method == "GET"){
            fs.readFile('./public/login.html', (err, data) =>{
                if(err){
                    res.writeHead(404)
                    res.end('error: page not found')
                }else{
                    res.writeHead(200, {"Content-Type": "text/html"})
                    res.write(data)
                }
                res.end()
            });
        }else if(method == "POST"){
            // Tangani data login yang dikirim melalui POST
            let body = '';
            req.on('data', chunk => {
                body += chunk.toString()
            })

            req.on('end', ()=>{
                const formData = querystring.parse(body)
                const username = formData.username
                const password = formData.password

                // validasi login dengan array users
                const user = users.find(u => u.username === username && u.password === password)

                if(user){
                    // redirect ke halaman home jika login berhasil
                    res.writeHead(302, {'location' : '/home'})
                }else{
                    // redirect kembali ke halaman login jika login gagal
                    res.writeHead(302, {'location' : '/'})
                }
                res.end()
            })
        }
        
    }else if(reqUrl == "/home"){
        fs.readFile(`./public/index.html`, (err, data) =>{
            if(err) {
                res.writeHead(404)
                res.end('error: file not found')
            }else{
                res.writeHead(200, {"Content-Type" : "text/html"})
                res.write(data)
            }
        })
    }else if (reqUrl.startsWith("/transaction")) {
        const parsedUrl = url.parse(reqUrl, true);  // Parse URL dengan parameter query
        const { pathname, query } = parsedUrl;
    
        if (pathname === "/transaction" && method === "GET") {
            // Menampilkan halaman transaksi
            fs.readFile(`./public/transaction.html`, (err, data) => {
                if (err) {
                    res.writeHead(404);
                    res.end('Error: File not found');
                } else {
                    res.writeHead(200, { "Content-Type": "text/html" });
                    res.write(data);
                }
                res.end();
            });
            } else {
                res.writeHead(404);
                res.end("Error: Page not found");
            }
        } else if(reqUrl == "/image/logo"){
        fs.readFile('./public/logo.png', (err, data) =>{
            if(err){
                res.writeHead(404)
                res.end('error: page not found')
            }else{
                res.writeHead(200, {"Content-Type": "text/html"})
                res.write(data)
            }
            res.end()
        });
    } else if(reqUrl == "/image/banner"){
        fs.readFile('./public/banner.jpeg', (err, data) =>{
            if(err){
                res.writeHead(404)
                res.end('error: page not found')
            }else{
                res.writeHead(200, {"Content-Type": "text/html"})
                res.write(data)
            }
            res.end()
        });
    }

}).listen(port, hostname, () =>{
    console.log(`server running at http://${port}:${hostname}`)
})