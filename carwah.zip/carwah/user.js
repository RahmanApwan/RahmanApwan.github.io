// File: users.js
const users = [
    { username: 'userlsp', password: 'smkn2bjm' },
];

module.exports = users;